<?php
//koneksi
    define('host','localhost');
    define('user','root');
    define('password','');
    define('db_name','data');
    
    $conn =NEW MYSQLI(host,user,password,db_name) or die(mysql_errno());
//tambah data

if(isset($_POST['tambah'])){
    $nama=$conn->real_escape_string($_POST['nama']);
    $username=$conn->real_escape_string($_POST['username']);
    $password=$conn->real_escape_string($_POST['password']);
    $email=$conn->real_escape_string($_POST['email']);
    $cek = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM list WHERE username='$username' or email='$email'"));
                          if ($cek > 0){
                          echo "<script>window.alert('nama atau email yang anda masukan sudah ada')
                          window.location='http://localhost:82/tugas1/'</script>";
                          }else{
                            $SQL=$conn ->query("INSERT INTO list(nama,username,password,email)VALUES('$nama','$username','$password','$email')" );
                            if($SQL){
                                echo "<script>window.alert('Berhasil tambah data')window.location='http://localhost:82/rachacha/list'</script>";
                          }
                        }
   
}
//edit
if(isset($_GET['edit'])){
    $SQL=$conn->query("SELECT * FROM list WHERE id=".$_GET['edit']);
    $tampilkan=$SQL->fetch_array (MYSQLI_BOTH);
}
if(isset($_POST['update'])){
    $SQL=$conn->query("UPDATE list SET nama='".$_POST['nama']."',username='".$_POST['username']."',password='".$_POST['password']."',email='".$_POST['email']."' WHERE id=".$_GET['edit']);
    if($SQL){
        echo"<script>window.alert('sukses Update')
        window.location='http://localhost:82/tugas1/'</script>";
    }
}
//hapus
if(isset($_GET['delete'])){
    $SQL=$conn->query("DELETE FROM list WHERE id=".$_GET['delete']);
    if($SQL){
        echo"<script>window.alert('sukses hapus')
        window.location='http://localhost:82/tugas1/'</script>";
    }
}
//validasi hanya huruf di inputan nama

?>