<?php
    require_once 'koneksi.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>
    <div class="container">
        <div class="col-md-5">
            <h3> Form Tambah data</h3>
            <hr>
                <form action="" method="post">
                <div class="form-group">
                    <input type="text" name="nama" value="<?php if(isset($_GET['edit'])){ echo $tampilkan['0'];}?>" placeholder="Nama " class="form-control" autofocus required pattern="[a-zA-Z]+" oninvalid="this.setCustomValidity('Input hanya boleh dengan huruf a-z' )" patternrequired>
                </div>

                <div class="form-group">
                    <input type="text" name="username" value="<?php if(isset($_GET['edit'])){ echo $tampilkan['1'];}?>" placeholder="username " class="form-control" required>
                </div>

                <div class="form-group">
                    <input type="password" name="password" value="<?php if(isset($_GET['edit'])){ echo $tampilkan['2'];}?>" placeholder="password " class="form-control" required>
                </div>

                <div class="form-group">
                    <input type="email" name="email" value="<?php if(isset($_GET['edit'])){ echo $tampilkan['3'];}?>" placeholder="email" class="form-control" required>
                </div>
                <div class="form-group">
                <?php
                if(isset($_GET['edit'])){
                    ?>
                <button type="submit" class="btn btn-success" name="update">Update</button>
                <?php
                }else{
                    ?><button type="submit" class="btn btn-primary" name="tambah">Tambah</button>
                <?php
                }
                ?>
                </div>
        </div>

        <div class="col-md-7" style="border-left: 2px solid #00A8FF;">
        <h3> Data</h3>
            <form action="" method="post" accept-charset="utf-8">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama</th>
                            <th class="text-center">Username</th>
                            <th class="text-center">Email</th>
                            <th class="text-center">Aksi</th>
                        <tr>
                    </thead>
                        <?php
                            $SQL=$conn->query("SELECT * FROM list");
                            while ($rows=$SQL->fetch_array(MYSQLI_BOTH)){
                               @$no++;
                            
                        ?>

                    <tbody>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $rows['0']; ?></td>
                            <td><?php echo $rows['1']; ?></td>
                            <td><?php echo $rows['3']; ?></td>
                            <td>
                                <a href="?edit=<?php echo $rows['4']; ?>" title="Klik untuk edit" class="btn btn-success" onclik="return confirm('anda yakin untuk edit ini ?')">edit</a>
                                <a href="?delete=<?php echo $rows['4']; ?>" title="Klik untuk hapus" class="btn btn-danger" onclik="return confirm('anda yakin untuk hapus ini ?')">hapus</a>
                            </td>
                        <tr>
                    </tbody>
                    <?php
                            }
                    ?>

                </table>
            </form>
        </div>
        </div>
    
</body>
</html>